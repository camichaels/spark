'use client'

import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import styles from './inbox.module.css'

type Element = {
  id: string
  type: string
  source: string
  content: string | null
  metadata: Record<string, unknown>
  is_archived: boolean
  created_at: string
}

type Idea = {
  id: string
  title: string
}

export default function InboxPage() {
  const router = useRouter()
  const [elements, setElements] = useState<Element[]>([])
  const [ideas, setIdeas] = useState<Idea[]>([])
  const [loading, setLoading] = useState(true)

  // Triage state
  const [sendPickerFor, setSendPickerFor] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editDraft, setEditDraft] = useState('')
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)

  // Toast
  const [toast, setToast] = useState<string | null>(null)
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    loadInbox()
    loadIdeas()
  }, [])

  async function loadInbox() {
    const { data } = await supabase
      .from('elements')
      .select('*')
      .is('idea_id', null)
      .eq('is_archived', false)
      .neq('metadata->>drawer', 'true')
      .order('created_at', { ascending: false })

    if (data) setElements(data)
    setLoading(false)
  }

  async function loadIdeas() {
    const { data } = await supabase
      .from('ideas')
      .select('id, title')
      .eq('status', 'active')
      .order('sort_order', { ascending: true })

    if (data) setIdeas(data)
  }

  function showToast(message: string) {
    if (toastTimer.current) clearTimeout(toastTimer.current)
    setToast(message)
    toastTimer.current = setTimeout(() => setToast(null), 2200)
  }

  async function sendToIdea(elementId: string, ideaId: string) {
    const ideaTitle = ideas.find(i => i.id === ideaId)?.title || 'Idea'
    await supabase
      .from('elements')
      .update({ idea_id: ideaId })
      .eq('id', elementId)

    setElements(prev => prev.filter(e => e.id !== elementId))
    setSendPickerFor(null)
    showToast(`Sent to "${ideaTitle}"`)
  }

  async function moveToDrawer(elementId: string) {
    // Set drawer flag in metadata
    const el = elements.find(e => e.id === elementId)
    const currentMeta = (el?.metadata || {}) as Record<string, unknown>
    await supabase
      .from('elements')
      .update({ metadata: { ...currentMeta, drawer: 'true' } })
      .eq('id', elementId)

    setElements(prev => prev.filter(e => e.id !== elementId))
    showToast('Moved to Drawer')
  }

  async function deleteElement(elementId: string) {
    await supabase
      .from('elements')
      .delete()
      .eq('id', elementId)

    setElements(prev => prev.filter(e => e.id !== elementId))
    setConfirmDeleteId(null)
    showToast('Deleted')
  }

  async function saveEdit(elementId: string) {
    if (!editDraft.trim()) return
    await supabase
      .from('elements')
      .update({ content: editDraft.trim() })
      .eq('id', elementId)

    setElements(prev => prev.map(e =>
      e.id === elementId ? { ...e, content: editDraft.trim() } : e
    ))
    setEditingId(null)
    setEditDraft('')
  }

  function startEditing(el: Element) {
    setEditingId(el.id)
    setEditDraft(el.content || '')
  }

  function cancelEditing() {
    setEditingId(null)
    setEditDraft('')
  }

  // Render helpers
  function getMetaString(el: Element): string {
    const meta = el.metadata || {}
    const parts: string[] = []

    // Type label
    const typeLabel = el.type.charAt(0).toUpperCase() + el.type.slice(1)
    parts.push(typeLabel)

    // Domain for articles
    if (el.type === 'article' && meta.url) {
      try {
        const domain = new URL(meta.url as string).hostname.replace('www.', '')
        parts.push(domain)
      } catch { /* skip */ }
    }

    // File info
    if (el.type === 'file' && meta.file_name) {
      parts.push(meta.file_name as string)
    }

    // Date
    parts.push(
      new Date(el.created_at).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      })
    )

    return parts.join(' · ')
  }

  function renderElementContent(el: Element) {
    const meta = el.metadata || {}

    // Article with title
    if (el.type === 'article') {
      const title = (meta.title as string) || el.content
      const url = meta.url as string | undefined
      return (
        <>
          {title && (
            <div className={styles.articleTitle}>
              {url ? (
                <a href={url} target="_blank" rel="noopener noreferrer" className={styles.articleLink}>
                  {title}
                </a>
              ) : title}
            </div>
          )}
          {meta.description && (
            <div className={styles.articleDesc}>{meta.description as string}</div>
          )}
          {!meta.title && el.content && url && (
            <div className={styles.articleUrl}>{el.content}</div>
          )}
        </>
      )
    }

    // Image
    if (el.type === 'image') {
      const imageUrl = meta.storage_path
        ? supabase.storage.from('images').getPublicUrl(meta.storage_path as string).data.publicUrl
        : null
      return (
        <>
          {imageUrl ? (
            <div className={styles.imageWrapper}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={imageUrl} alt={el.content || 'Image'} className={styles.image} />
            </div>
          ) : (
            <div className={styles.imagePlaceholder}>Image</div>
          )}
          {el.content && <div className={styles.caption}>{el.content}</div>}
        </>
      )
    }

    // File
    if (el.type === 'file') {
      const fileName = (meta.file_name as string) || 'File'
      const fileExt = fileName.split('.').pop()?.toUpperCase() || 'FILE'
      return (
        <div className={styles.fileCard}>
          <span className={styles.fileIcon}>{fileExt}</span>
          <span className={styles.fileName}>{fileName}</span>
        </div>
      )
    }

    // Thought (default)
    return el.content ? (
      <div className={styles.thoughtText}>{el.content}</div>
    ) : null
  }

  if (loading) {
    return (
      <div className={styles.page}>
        <nav className={styles.nav}>
          <button onClick={() => router.push('/')} className={styles.backBtn}>← Home</button>
        </nav>
        <div className={styles.center}><p className={styles.muted}></p></div>
      </div>
    )
  }

  return (
    <div className={styles.page}>
      <nav className={styles.nav}>
        <button onClick={() => router.push('/')} className={styles.backBtn}>← Home</button>
      </nav>

      <main className={styles.container}>
        <header className={styles.header}>
          <h1 className={styles.title}>Inbox</h1>
          <span className={styles.count}>{elements.length} {elements.length === 1 ? 'item' : 'items'}</span>
        </header>

        {elements.length === 0 ? (
          <div className={styles.empty}>
            <p>Inbox is empty.</p>
            <p className={styles.muted}>
              Items added without an Idea land here for triage.
            </p>
          </div>
        ) : (
          <div className={styles.elementList}>
            {elements.map((el) => (
              <div key={el.id} className={styles.element}>
                {/* Meta line: type · domain · date */}
                <div className={styles.elementMeta}>{getMetaString(el)}</div>

                {/* Content — editable or display */}
                {editingId === el.id ? (
                  <div className={styles.editArea}>
                    <textarea
                      value={editDraft}
                      onChange={(e) => setEditDraft(e.target.value)}
                      className={styles.editTextarea}
                      autoFocus
                      rows={3}
                    />
                    <div className={styles.editActions}>
                      <button onClick={cancelEditing} className={styles.cancelBtn}>Cancel</button>
                      <button onClick={() => saveEdit(el.id)} className={styles.saveBtn}>Save</button>
                    </div>
                  </div>
                ) : (
                  <div className={styles.elementContent}>
                    {renderElementContent(el)}
                  </div>
                )}

                {/* Triage action bar */}
                {editingId !== el.id && (
                  <div className={styles.triageBar}>
                    <button
                      className={styles.triageBtn}
                      onClick={() => setSendPickerFor(sendPickerFor === el.id ? null : el.id)}
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.triageIcon}>
                        <path d="M22 2L11 13" />
                        <path d="M22 2L15 22L11 13L2 9L22 2Z" />
                      </svg>
                      Send to Idea
                    </button>
                    <button className={styles.triageBtn} onClick={() => moveToDrawer(el.id)}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.triageIcon}>
                        <path d="M21 8V21H3V8" />
                        <rect x="1" y="3" width="22" height="5" />
                        <line x1="10" y1="12" x2="14" y2="12" />
                      </svg>
                      Drawer
                    </button>
                    {(el.type === 'thought' || el.type === 'article') && (
                      <button className={styles.triageBtn} onClick={() => startEditing(el)}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.triageIcon}>
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                        </svg>
                        Edit
                      </button>
                    )}
                    <button
                      className={`${styles.triageBtn} ${styles.triageBtnDanger}`}
                      onClick={() => setConfirmDeleteId(el.id)}
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.triageIcon}>
                        <polyline points="3,6 5,6 21,6" />
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                      </svg>
                      Delete
                    </button>
                  </div>
                )}

                {/* Idea picker dropdown */}
                {sendPickerFor === el.id && (
                  <div className={styles.ideaPicker}>
                    <div className={styles.pickerLabel}>Send to:</div>
                    {ideas.length === 0 ? (
                      <p className={styles.muted}>No active ideas. Create one first.</p>
                    ) : (
                      ideas.map((idea) => (
                        <button
                          key={idea.id}
                          className={styles.pickerOption}
                          onClick={() => sendToIdea(el.id, idea.id)}
                        >
                          {idea.title}
                        </button>
                      ))
                    )}
                    <button className={styles.pickerCancel} onClick={() => setSendPickerFor(null)}>Cancel</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Delete Confirm Dialog */}
      {confirmDeleteId && (
        <>
          <div className={styles.overlay} onClick={() => setConfirmDeleteId(null)} />
          <div className={styles.dialog}>
            <p className={styles.dialogMessage}>Delete this item?</p>
            <p className={styles.dialogSubtext}>This cannot be undone.</p>
            <div className={styles.dialogActions}>
              <button onClick={() => setConfirmDeleteId(null)} className={styles.dialogCancel}>Cancel</button>
              <button onClick={() => deleteElement(confirmDeleteId)} className={styles.dialogConfirm}>Delete</button>
            </div>
          </div>
        </>
      )}

      {/* Toast */}
      {toast && (
        <div className={styles.toast}>{toast}</div>
      )}
    </div>
  )
}