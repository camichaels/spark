'use client'

import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import styles from './drawer.module.css'

type Element = {
  id: string
  type: string
  source: string
  content: string | null
  metadata: Record<string, unknown>
  is_archived: boolean
  created_at: string
}

type Idea = {
  id: string
  title: string
}

export default function DrawerPage() {
  const router = useRouter()
  const [elements, setElements] = useState<Element[]>([])
  const [ideas, setIdeas] = useState<Idea[]>([])
  const [loading, setLoading] = useState(true)

  // Quick add
  const [quickAdd, setQuickAdd] = useState('')
  const quickAddRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const cameraInputRef = useRef<HTMLInputElement>(null)

  // ••• modal
  const [showAddOptions, setShowAddOptions] = useState(false)

  // Triage state
  const [sendPickerFor, setSendPickerFor] = useState<string | null>(null)
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)

  // Toast
  const [toast, setToast] = useState<string | null>(null)
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Mobile detection
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    setIsMobile(/iPhone|iPad|iPod|Android/i.test(navigator.userAgent))
  }, [])

  useEffect(() => {
    loadDrawer()
    loadIdeas()
  }, [])

  async function loadDrawer() {
    const { data } = await supabase
      .from('elements')
      .select('*')
      .is('idea_id', null)
      .eq('is_archived', false)
      .eq('metadata->>drawer', 'true')
      .order('created_at', { ascending: false })
    if (data) setElements(data)
    setLoading(false)
  }

  async function loadIdeas() {
    const { data } = await supabase
      .from('ideas')
      .select('id, title')
      .eq('status', 'active')
      .order('sort_order', { ascending: true })
    if (data) setIdeas(data)
  }

  function showToast(message: string) {
    if (toastTimer.current) clearTimeout(toastTimer.current)
    setToast(message)
    toastTimer.current = setTimeout(() => setToast(null), 2200)
  }

  async function handleQuickAdd() {
    if (!quickAdd.trim()) return
    const { data: session } = await supabase.auth.getSession()
    const userId = session?.session?.user?.id
    if (!userId) return

    const content = quickAdd.trim()
    const urlPattern = /^(https?:\/\/|www\.)/i
    const isUrl = urlPattern.test(content)

    const { error } = await supabase.from('elements').insert({
      user_id: userId,
      idea_id: null,
      type: isUrl ? 'article' : 'thought',
      source: 'user',
      content,
      metadata: isUrl ? { url: content, drawer: 'true' } : { drawer: 'true' },
      is_archived: false,
    })

    if (!error) {
      setQuickAdd('')
      if (quickAddRef.current) quickAddRef.current.style.height = 'auto'
      loadDrawer()
      showToast('Added to Drawer')
    }
  }

  // ••• modal: file selected
  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setShowAddOptions(false)

    const { data: session } = await supabase.auth.getSession()
    const userId = session?.session?.user?.id
    if (!userId) return

    const isImage = file.type.startsWith('image/')
    const bucket = isImage ? 'images' : 'files'
    const filePath = `${userId}/${Date.now()}-${file.name}`

    const { error: uploadError } = await supabase.storage.from(bucket).upload(filePath, file)
    if (uploadError) { showToast('Upload failed'); e.target.value = ''; return }

    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(filePath)

    const { error } = await supabase.from('elements').insert({
      user_id: userId,
      idea_id: null,
      type: isImage ? 'image' : 'file',
      source: 'user',
      content: file.name,
      metadata: {
        drawer: 'true',
        file_name: file.name,
        file_size: file.size,
        file_type: file.type,
        storage_path: filePath,
        public_url: urlData.publicUrl,
      },
      is_archived: false,
    })

    if (!error) { loadDrawer(); showToast('Added to Drawer') }
    e.target.value = ''
  }

  // ••• modal: paste link
  function handlePasteLinkOption() {
    setShowAddOptions(false)
    quickAddRef.current?.focus()
    navigator.clipboard.readText().then((text) => {
      const urlPattern = /^(https?:\/\/|www\.)/i
      if (urlPattern.test(text.trim())) {
        setQuickAdd(text.trim())
      } else {
        showToast('No URL found on clipboard')
      }
    }).catch(() => {
      showToast('Could not read clipboard')
    })
  }

  // Clipboard paste on textarea
  async function handlePaste(e: React.ClipboardEvent) {
    const items = e.clipboardData?.items
    if (!items) return

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.startsWith('image/')) {
        e.preventDefault()
        const file = items[i].getAsFile()
        if (!file) return

        const { data: session } = await supabase.auth.getSession()
        const userId = session?.session?.user?.id
        if (!userId) return

        const named = new File([file], `pasted-image-${Date.now()}.png`, { type: file.type })
        const filePath = `${userId}/${Date.now()}-${named.name}`

        const { error: uploadError } = await supabase.storage.from('images').upload(filePath, named)
        if (uploadError) { showToast('Upload failed'); return }

        const { data: urlData } = supabase.storage.from('images').getPublicUrl(filePath)

        const { error } = await supabase.from('elements').insert({
          user_id: userId,
          idea_id: null,
          type: 'image',
          source: 'user',
          content: named.name,
          metadata: {
            drawer: 'true',
            file_name: named.name,
            file_size: named.size,
            file_type: named.type,
            storage_path: filePath,
            public_url: urlData.publicUrl,
          },
          is_archived: false,
        })

        if (!error) { loadDrawer(); showToast('Image added to Drawer') }
        return
      }
    }
  }

  async function sendToIdea(elementId: string, ideaId: string) {
    const ideaTitle = ideas.find(i => i.id === ideaId)?.title || 'Idea'
    const el = elements.find(e => e.id === elementId)
    const meta = { ...(el?.metadata || {}) } as Record<string, unknown>
    delete meta.drawer

    await supabase.from('elements').update({ idea_id: ideaId, metadata: meta }).eq('id', elementId)
    setElements(prev => prev.filter(e => e.id !== elementId))
    setSendPickerFor(null)
    showToast(`Sent to "${ideaTitle}"`)
  }

  async function deleteElement(elementId: string) {
    await supabase.from('elements').delete().eq('id', elementId)
    setElements(prev => prev.filter(e => e.id !== elementId))
    setConfirmDeleteId(null)
    showToast('Deleted')
  }

  function getMetaString(el: Element): string {
    const meta = el.metadata || {}
    const parts: string[] = []
    parts.push(el.type.charAt(0).toUpperCase() + el.type.slice(1))
    if (el.type === 'article' && meta.url) {
      try { parts.push(new URL(meta.url as string).hostname.replace('www.', '')) } catch { /* skip */ }
    }
    if (el.type === 'file' && meta.file_name) parts.push(meta.file_name as string)
    parts.push(new Date(el.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }))
    return parts.join(' · ')
  }

  function renderElementContent(el: Element) {
    const meta = el.metadata || {}

    if (el.type === 'article') {
      const title = (meta.title as string) || el.content
      const url = meta.url as string | undefined
      return (
        <>
          {title && (
            <div className={styles.articleTitle}>
              {url ? <a href={url} target="_blank" rel="noopener noreferrer" className={styles.articleLink}>{title}</a> : title}
            </div>
          )}
          {meta.description && <div className={styles.articleDesc}>{meta.description as string}</div>}
          {!meta.title && el.content && url && <div className={styles.articleUrl}>{el.content}</div>}
        </>
      )
    }

    if (el.type === 'image') {
      const imageUrl = meta.storage_path
        ? supabase.storage.from('images').getPublicUrl(meta.storage_path as string).data.publicUrl
        : null
      return (
        <>
          {imageUrl ? (
            <div className={styles.imageWrapper}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={imageUrl} alt={el.content || 'Image'} className={styles.image} />
            </div>
          ) : (
            <div className={styles.imagePlaceholder}>Image</div>
          )}
          {el.content && <div className={styles.caption}>{el.content}</div>}
        </>
      )
    }

    if (el.type === 'file') {
      const fileName = (meta.file_name as string) || 'File'
      const fileExt = fileName.split('.').pop()?.toUpperCase() || 'FILE'
      return (
        <div className={styles.fileCard}>
          <span className={styles.fileIcon}>{fileExt}</span>
          <span className={styles.fileName}>{fileName}</span>
        </div>
      )
    }

    return el.content ? <div className={styles.thoughtText}>{el.content}</div> : null
  }

  if (loading) {
    return (
      <div className={styles.page}>
        <nav className={styles.nav}>
          <button onClick={() => router.push('/')} className={styles.backBtn}>← Home</button>
        </nav>
        <div className={styles.center}><p className={styles.muted}></p></div>
      </div>
    )
  }

  return (
    <div className={styles.page}>
      <nav className={styles.nav}>
        <button onClick={() => router.push('/')} className={styles.backBtn}>← Home</button>
      </nav>

      <main className={styles.container}>
        <header className={styles.header}>
          <h1 className={styles.title}>Drawer</h1>
          <span className={styles.count}>{elements.length} {elements.length === 1 ? 'item' : 'items'}</span>
        </header>

        {/* Quick Add — matches Idea page: textarea, then [Post] [•••] row */}
        <div className={styles.quickAdd}>
          <textarea
            ref={quickAddRef}
            value={quickAdd}
            onChange={(e) => { setQuickAdd(e.target.value); e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px' }}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleQuickAdd() } }}
            onPaste={handlePaste}
            placeholder="Stash a thought, paste a link..."
            className={styles.quickAddInput}
            rows={1}
          />
          <div className={styles.quickAddActions}>
            {quickAdd.trim() && (
              <button onClick={handleQuickAdd} className={styles.postBtn}>Post</button>
            )}
            <span className={styles.quickAddMore} onClick={() => setShowAddOptions(true)}>•••</span>
          </div>
          <input ref={fileInputRef} type="file" style={{ display: 'none' }} onChange={handleFileSelected} />
          <input ref={imageInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleFileSelected} />
          <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={handleFileSelected} />
        </div>

        {elements.length === 0 ? (
          <div className={styles.empty}>
            <p>Drawer is empty.</p>
            <p className={styles.muted}>Stash thoughts, links, and files here for later — things that don't belong to an Idea yet.</p>
          </div>
        ) : (
          <div className={styles.elementList}>
            {elements.map((el) => (
              <div key={el.id} className={styles.element}>
                <div className={styles.elementMeta}>{getMetaString(el)}</div>
                <div className={styles.elementContent}>{renderElementContent(el)}</div>
                <div className={styles.actionBar}>
                  <button className={styles.actionBtn} onClick={() => setSendPickerFor(sendPickerFor === el.id ? null : el.id)}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.actionIcon}>
                      <path d="M22 2L11 13" /><path d="M22 2L15 22L11 13L2 9L22 2Z" />
                    </svg>
                    Send to Idea
                  </button>
                  <button className={`${styles.actionBtn} ${styles.actionBtnDanger}`} onClick={() => setConfirmDeleteId(el.id)}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={styles.actionIcon}>
                      <polyline points="3,6 5,6 21,6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                    Delete
                  </button>
                </div>
                {sendPickerFor === el.id && (
                  <div className={styles.ideaPicker}>
                    <div className={styles.pickerLabel}>Send to:</div>
                    {ideas.length === 0 ? (
                      <p className={styles.muted}>No active ideas. Create one first.</p>
                    ) : (
                      ideas.map((idea) => (
                        <button key={idea.id} className={styles.pickerOption} onClick={() => sendToIdea(el.id, idea.id)}>{idea.title}</button>
                      ))
                    )}
                    <button className={styles.pickerCancel} onClick={() => setSendPickerFor(null)}>Cancel</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* ===== ADD OPTIONS MODAL (•••) ===== */}
      {showAddOptions && (
        <>
          <div className={styles.overlay} onClick={() => setShowAddOptions(false)} />
          <div className={styles.addOptionsModal}>
            <button className={styles.addOption} onClick={() => { setShowAddOptions(false); imageInputRef.current?.click() }}>Choose image</button>
            <button className={styles.addOption} onClick={() => { setShowAddOptions(false); fileInputRef.current?.click() }}>Add file</button>
            <button className={styles.addOption} onClick={handlePasteLinkOption}>Paste link</button>
            {isMobile && (
              <button className={styles.addOption} onClick={() => { setShowAddOptions(false); cameraInputRef.current?.click() }}>Take photo</button>
            )}
          </div>
        </>
      )}

      {/* Delete Confirm */}
      {confirmDeleteId && (
        <>
          <div className={styles.overlay} onClick={() => setConfirmDeleteId(null)} />
          <div className={styles.dialog}>
            <p className={styles.dialogMessage}>Delete this item?</p>
            <p className={styles.dialogSubtext}>This cannot be undone.</p>
            <div className={styles.dialogActions}>
              <button onClick={() => setConfirmDeleteId(null)} className={styles.dialogCancel}>Cancel</button>
              <button onClick={() => deleteElement(confirmDeleteId)} className={styles.dialogConfirm}>Delete</button>
            </div>
          </div>
        </>
      )}

      {toast && <div className={styles.toast}>{toast}</div>}
    </div>
  )
}